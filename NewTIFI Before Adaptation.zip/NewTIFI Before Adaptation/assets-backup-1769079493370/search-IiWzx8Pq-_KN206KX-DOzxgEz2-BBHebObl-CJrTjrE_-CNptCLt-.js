import{H as e}from"./index-61tQbqRW.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=e("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);export{c as r};
//# sourceMappingURL=search-IiWzx8Pq-_KN206KX-DOzxgEz2-BBHebObl-CJrTjrE_-CNptCLt-.js.map
