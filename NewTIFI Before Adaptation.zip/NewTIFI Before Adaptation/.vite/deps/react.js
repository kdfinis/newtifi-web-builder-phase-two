import {
  require_react
} from "./chunk-ZCND2HWC.js";
export default require_react();
//# sourceMappingURL=react.js.map
