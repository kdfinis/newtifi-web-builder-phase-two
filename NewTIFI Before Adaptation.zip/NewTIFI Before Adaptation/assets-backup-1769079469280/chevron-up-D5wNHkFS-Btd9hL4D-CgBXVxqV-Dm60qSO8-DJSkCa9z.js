import{K as o}from"./index-hxOYbB7i.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=o("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
* @license lucide-react v0.462.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/const n=o("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);export{n as e,r};
//# sourceMappingURL=chevron-up-D5wNHkFS-Btd9hL4D-CgBXVxqV-Dm60qSO8-DJSkCa9z.js.map
