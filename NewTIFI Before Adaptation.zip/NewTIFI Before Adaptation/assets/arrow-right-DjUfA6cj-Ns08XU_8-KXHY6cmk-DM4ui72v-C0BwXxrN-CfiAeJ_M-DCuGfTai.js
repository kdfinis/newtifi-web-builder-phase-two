import{U as h}from"./index-zGSIE1dd.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=h("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);export{o as h};
//# sourceMappingURL=arrow-right-DjUfA6cj-Ns08XU_8-KXHY6cmk-DM4ui72v-C0BwXxrN-CfiAeJ_M-DCuGfTai.js.map
